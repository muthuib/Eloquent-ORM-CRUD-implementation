<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Programs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body>

<section style="padding-top:60px;">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="card">
<div class="card-header">
All Programs <a href="/add-program" class="btn btn-success">Add new program</a>
</div>
<div class="card-body">

<?php if(Session::has('program-deleted')): ?>
<div class="alert alert-success" role="alert">
<?php echo e(Session::get('program_deleted')); ?>

</div>
<?php endif; ?>

<table class="table table-striped">
<thead>
<tr>

<th>Program Title</ th>
<th>Program Description</th>
<th>Action</th>
</tr>
</thead>
       <tbody>
       <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       
       <td><?php echo e($program->title); ?></td>
       <td><?php echo e($program->body); ?></td>
       <td>
       <a href="/program/<?php echo e($program->id); ?>" class="btn btn-info">Details</a>
       <a href="/edit-program/<?php echo e($program->id); ?>" class="btn btn-success">Update</a>
       <a href="/delete-program/<?php echo e($program->id); ?>" class="btn btn-danger">Delete</a>
       </td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
       </table>

</div>
</div>
</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\User\AwesomeProject\resources\views/program.blade.php ENDPATH**/ ?>