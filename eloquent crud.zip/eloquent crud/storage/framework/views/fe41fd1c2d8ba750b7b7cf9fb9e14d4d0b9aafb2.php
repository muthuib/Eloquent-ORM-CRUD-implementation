<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update program</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body>

<section style="padding-top:60px;">
<div class="container">
<div class="row">
<div class="col-md-6 offset-md-3">
<div class="card">
<div class="card-header">
Update Program
</div>
<div class="card-body">
<?php if(Session::has('program_updated')): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e(session::get('program_updated')); ?>

   </div>
<?php endif; ?> 

<form method="POST" action="<?php echo e(route('program.update')); ?>">
@
<input type="hidden" name="id" value="<?php echo e($program->id); ?>"/>
<div class="form-group">
<label for="title">Update Program</label>
<input type="text" name="title" class="form-control" placeholder="Enter Program name" value="<?php echo e($program->title); ?>"/><br>
</div>
<div class="form-group">
<label for="body">edit Program description</label>
<textarea name="body" class="form-control" rows="3" placeholder="Description............."><?php echo e($program->body); ?></textarea>
</div>


<button type="submit" class="btn btn-success" >Update Program</button>
<a href="/program" class="btn btn-success">All Programs</a>
</div>
</div>
</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\User\AwesomeProject\resources\views/edit-program.blade.php ENDPATH**/ ?>