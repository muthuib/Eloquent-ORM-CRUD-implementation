<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Program;

class ProgramController extends Controller
{
    //
    public function addprogram()
    {
        return view('add-program');
    }
    public function createProgram(Request $request)
    {
        $post = new program();
        $post->title = $request->title;
        $post->body = $request->body;
        $post->save();
        return back()->with('program_created','Program has been creates succesfully');
    }

    public function getProgram()
    {
        $program = Program::orderBy('id','DESC')->get();
        return view('program',compact('program'));
    }

    public function getProgramById($id)
    {
        $program = program::where('id',$id)->first();
        return view('single-program',compact('program'));
    }

    public function deleteProgram($id)
    {
        program::where('id',$id)->delete();
        return back()->with('program_deleted','program has been deleted successfully');
    }

    public function editprogram($id)
    {
        $program = program::find($id);
        return view('edit-program',compact('program'));
    }

    public function updateprogram(Request $request)
    {
        $post = program::find($request->id);
        $post->title = $request->title;
        $post->body = $request->body;
        $post->save();
        return back()->with('program_updated','program has been updated successfully');
    }
}
