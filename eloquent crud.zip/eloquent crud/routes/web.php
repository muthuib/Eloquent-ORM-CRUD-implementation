<?php
use App\Http\Controllers\ProgramController; 
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/add-program',[ProgramController::class,'addprogram']);
Route::post('/create-program',[ProgramController::class,'createProgram'])->name('post.create');
Route::get('/program',[ProgramController::class,'getProgram']);
Route::get('/program/{id}',[ProgramController::class,'getProgramById']);
Route::get('/delete-program/{id}',[ProgramController::class,'deleteprogram']);
Route::get('/edit-program/{id}',[ProgramController::class,'editprogram']);
Route::get('/update-program/{id}',[ProgramController::class,'updateprogram'])->name('program.update');